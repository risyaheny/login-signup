<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin page</title>
    <link rel="stylesheet" href="style/style.css">
</head>
<body>

<div class="container">

   <div class="content">
      <h3> halo, <span>sobat!</span></h3>
      <h1>MOOC Inspektorat<span></span></h1>
      <p> silahkan login atau register jika anda belum memiliki akun <p>
        <a href="login_form.php" class="btn">login</a>
        <a href="register_form.php" class="btn">register</a>
    </div>

</div>
    
</body>
</html>